import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

function UserDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div style={{ maxWidth: 480, margin: '80px auto', padding: 24, border: '1px solid #ddd', borderRadius: 8 }}>
      <h2>User Dashboard</h2>
      <p>Welcome, <strong>{user?.username}</strong>!</p>
      <p>Role: <strong>{user?.role}</strong></p>
      {user?.role === 'admin' && (
        <button onClick={() => navigate('/admin')}
          style={{ marginRight: 10, padding: '8px 16px', background: '#9c27b0', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer' }}>
          Go to Admin Panel
        </button>
      )}
      <button onClick={handleLogout}
        style={{ padding: '8px 16px', background: '#d32f2f', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer' }}>
        Logout
      </button>
    </div>
  );
}

export default UserDashboard;
