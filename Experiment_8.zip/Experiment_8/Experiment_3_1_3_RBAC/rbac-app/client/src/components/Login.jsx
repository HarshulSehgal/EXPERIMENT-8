import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

function Login() {
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const { data } = await axios.post('http://localhost:3001/api/login', form);
      login(data.token);
      navigate(data.role === 'admin' ? '/admin' : '/dashboard');
    } catch (err) {
      setError(err.response?.data?.error || 'Login failed');
    }
  };

  return (
    <div style={{ maxWidth: 380, margin: '80px auto', padding: 24, border: '1px solid #ddd', borderRadius: 8 }}>
      <h2>Login</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <div style={{ marginBottom: 12 }}>
        <input name="username" placeholder="Username"
          value={form.username} onChange={handleChange} required
          style={{ width: '100%', padding: 8, boxSizing: 'border-box' }} />
      </div>
      <div style={{ marginBottom: 12 }}>
        <input name="password" type="password" placeholder="Password"
          value={form.password} onChange={handleChange} required
          style={{ width: '100%', padding: 8, boxSizing: 'border-box' }} />
      </div>
      <button onClick={handleSubmit} style={{ width: '100%', padding: 10, background: '#1976d2', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer' }}>
        Sign In
      </button>
    </div>
  );
}

export default Login;
