import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function RoleRoute({ children, roles }) {
  const { user } = useAuth();

  if (!user) return <Navigate to="/login" replace />;

  if (!roles.includes(user.role))
    return <h2 style={{ color: 'red', textAlign: 'center', marginTop: 80 }}>403 — Unauthorized</h2>;

  return children;
}

export default RoleRoute;
