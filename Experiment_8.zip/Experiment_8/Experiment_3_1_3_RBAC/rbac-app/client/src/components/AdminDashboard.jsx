import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

function AdminDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div style={{ maxWidth: 540, margin: '80px auto', padding: 24, border: '2px solid #9c27b0', borderRadius: 8 }}>
      <h2 style={{ color: '#9c27b0' }}>Admin Dashboard</h2>
      <p>Welcome, <strong>{user?.username}</strong>!</p>
      <p>Role: <strong style={{ color: '#9c27b0' }}>{user?.role}</strong></p>
      <hr />
      <h3>Admin Controls</h3>
      <p>You have full access to all system features.</p>
      <div style={{ marginTop: 16 }}>
        <button onClick={() => navigate('/dashboard')}
          style={{ marginRight: 10, padding: '8px 16px', background: '#1976d2', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer' }}>
          User Dashboard
        </button>
        <button onClick={handleLogout}
          style={{ padding: '8px 16px', background: '#d32f2f', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer' }}>
          Logout
        </button>
      </div>
    </div>
  );
}

export default AdminDashboard;
