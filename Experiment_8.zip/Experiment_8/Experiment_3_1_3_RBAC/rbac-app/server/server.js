const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const User = require('./models/User');
const { verifyToken, requireRole } = require('./middleware/auth');

const SECRET = process.env.JWT_SECRET || 'secret123';
const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/rbac-app')
  .then(() => console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB error:', err));

// Register
app.post('/api/register', async (req, res) => {
  try {
    const { username, password, role } = req.body;
    const user = new User({ username, password, role });
    await user.save();
    res.json({ message: 'User created' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Login
app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user || !(await user.comparePassword(password)))
      return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign(
      { id: user._id, username: user.username, role: user.role },
      SECRET,
      { expiresIn: '1h' }
    );
    res.json({ token, role: user.role });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// User route — any authenticated user
app.get('/api/user/dashboard', verifyToken, (req, res) => {
  res.json({ message: `Hello ${req.user.username}`, role: req.user.role });
});

// Admin route — admin only
app.get('/api/admin/dashboard', verifyToken, requireRole('admin'), (req, res) => {
  res.json({ message: 'Admin Dashboard', users: [] });
});

app.listen(3001, () => console.log('Server on http://localhost:3001'));
