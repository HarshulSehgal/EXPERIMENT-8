# Experiment 3.1.3 — Role-Based Access Control (RBAC)

## Setup & Run

### Step 1 — Start MongoDB
```bash
mongod
```

### Step 2 — Backend
```bash
cd rbac-app/server
npm install
node server.js
# Server runs at http://localhost:3001
```

### Step 3 — Frontend
```bash
cd rbac-app/client
npm install
npm start
# App opens at http://localhost:3000
```

### Step 4 — Seed Test Users (via curl or Postman)
```bash
# Register Admin
curl -X POST http://localhost:3001/api/register \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123","role":"admin"}'

# Register User
curl -X POST http://localhost:3001/api/register \
  -H "Content-Type: application/json" \
  -d '{"username":"user1","password":"user123","role":"user"}'
```

## Test Credentials
| Role  | Username | Password  |
|-------|----------|-----------|
| Admin | admin    | admin123  |
| User  | user1    | user123   |

## Expected Behaviour
- Admin → sees Admin Dashboard at /admin
- User → redirected to /dashboard, sees 403 if visiting /admin
- Unauthenticated → redirected to /login
