# Experiment 8 — Full-Stack Authentication & Authorization

## Contents

| Folder | Experiment | Topic |
|--------|------------|-------|
| Experiment_3_1_1_Login_Form | 3.1.1 | Login Form with React State Management |
| Experiment_3_1_2_JWT_Protected_Routes | 3.1.2 | Protected Routes with JWT Verification |
| Experiment_3_1_3_RBAC | 3.1.3 | Role-Based Access Control (RBAC) |

---

## Quick Start Guide

### Experiment 3.1.1
```bash
cd Experiment_3_1_1_Login_Form/login-form
npm install
npm start
```
- URL: http://localhost:3000
- Email: admin@test.com | Password: password123

---

### Experiment 3.1.2
```bash
# Terminal 1
cd Experiment_3_1_2_JWT_Protected_Routes/jwt-auth-app/server
npm install && node server.js

# Terminal 2
cd Experiment_3_1_2_JWT_Protected_Routes/jwt-auth-app/client
npm install && npm start
```
- Username: admin | Password: password123

---

### Experiment 3.1.3
```bash
# Start MongoDB first
mongod

# Terminal 1
cd Experiment_3_1_3_RBAC/rbac-app/server
npm install && node server.js

# Terminal 2
cd Experiment_3_1_3_RBAC/rbac-app/client
npm install && npm start
```
- Seed users via POST /api/register (see experiment README)
- Admin: admin / admin123 | User: user1 / user123
