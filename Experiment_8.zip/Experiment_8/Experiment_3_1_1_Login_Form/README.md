# Experiment 3.1.1 — Login Form with React State Management

## Setup & Run

```bash
cd login-form
npm install
npm start
```

App opens at http://localhost:3000

## Test Credentials
| Field    | Value             |
|----------|-------------------|
| Email    | admin@test.com    |
| Password | password123       |
