# Experiment 3.1.2 — Protected Routes with JWT Verification

## Setup & Run

### Terminal 1 — Backend
```bash
cd jwt-auth-app/server
npm install
node server.js
# Server runs at http://localhost:3001
```

### Terminal 2 — Frontend
```bash
cd jwt-auth-app/client
npm install
npm start
# App opens at http://localhost:3000
```

## Test Credentials
| Field    | Value       |
|----------|-------------|
| Username | admin       |
| Password | password123 |
